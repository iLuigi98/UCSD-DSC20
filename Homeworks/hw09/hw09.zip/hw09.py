##############################################################################
# Problem 1
##############################################################################

# Copy Lab09.py and LinkNode.py from your lab directory into this directory,
# so you can import it here.

## IMPORT LAB HERE ##

def parentheses_checker(string):
    """
    :param string: a nonempty string
    :returns: a boolean value
    
    >>> parentheses_checker("()")
    True
    >>> parentheses_checker("()()")
    True
    >>> parentheses_checker("(()))")
    False
    >>> parentheses_checker("({x})")
    True
    >>> parentheses_checker("{[}]")
    False
    >>> parentheses_checker("((x))")
    True
    """
    # Your code here


##############################################################################
# Problem 2
##############################################################################
import numpy as np

class Queue:
    """
    A queue, dequeues from front and enqueues at rear
    >>> a=Queue()
    >>> a.enqueue(1)
    >>> a.enqueue(2)
    >>> a.enqueue(3)
    >>> a.enqueue(4)
    >>> a.enqueue(5)
    >>> a.print_queue()
    [ | 1 | 2 | 3 | 4 | 5 | ]
    >>> a.front
    0
    >>> a.rear
    5
    >>> a.data
    array([1, 2, 3, 4, 5, None], dtype=object)
    >>> a.capacity
    6
    >>> a.dequeue()
    1
    >>> a.print_queue()
    [ | 2 | 3 | 4 | 5 | ]
    >>> a.front
    1
    >>> a.rear
    5
    
    >>> a=Queue(10)
    >>> a.capacity
    10
    
    >>> b=Queue()
    >>> b.dequeue()
    Traceback (most recent call last):
    ...
    AssertionError: attempt to dequeue from an empty queue
    
    >>> b.enqueue(1)
    >>> b.enqueue(max)
    >>> b.print_queue()
    [ | 1 | <built-in function max> | ]
    >>> b.dequeue()
    1
    >>> b.dequeue()
    <built-in function max>
    >>> b.front
    2
    >>> b.rear
    2
    >>> b.dequeue()
    Traceback (most recent call last):
    ...
    AssertionError: attempt to dequeue from an empty queue
    """
    
    def __init__(self,capacity=3):
        """
        :param capacity: a positive integer
        >>> q = Queue()
        """
        # Your Code Here
    
    
    def dequeue(self):
        """
        dequeues from the front of the queue
        
        >>> q = Queue()
        >>> q.dequeue()
        Traceback (most recent call last):
        ...
        AssertionError: attempt to dequeue from an empty queue
        """
        # Your Code Here
        

    def enqueue(self,elem):
        """
        enqueue at the rear of the queue
        :param elem: a value that is not None

        >>> q = Queue()
        >>> q.enqueue("a")
        """
        # Your Code Here


    def expand(self):
        """
        expand the capacity of the circular array when needed
        >>> q = Queue()
        >>> q.capacity
        3
        >>> q.expand()
        >>> q.capacity
        6
        """
        # Your Code Here

    def is_full(self):
        """
        checks if circular array is full
        >>> q = Queue()
        >>> for i in range(4): q.enqueue(i)
        >>> q.data
        array([0, 1, 2, 3, None, None], dtype=object)
        >>> q.is_full()
        False
        """
        # Your Code Here


    def is_empty(self):
        """
        checks if circular array is full
        >>> q = Queue()
        >>> q.is_empty()
        True
        """
        # Your Code Here


    def print_queue(self):
        """
        prints out queue in a human-friendly format
        >>> q = Queue()
        >>> for i in range(5): q.enqueue(i)
        >>> q.print_queue()
        [ | 0 | 1 | 2 | 3 | 4 | ]
        >>> p = Queue()
        >>> p.print_queue()
        []
        """
        # Your Code Here

# Q 2.2: Cursed Carousel

def cursed_carousel(n, m):
    """
    n is the number of customers in line
    m is the number of customers sent to the back of the line
    return the number of the customer which is last to be served
    :param n: a positive integer
    :param m: a positive integer
    >>> cursed_carousel(10,2)
    2
    4
    6
    8
    10
    3
    7
    1
    9
    5
    >>> cursed_carousel(4,7)
    3
    4
    1
    2
    >>> cursed_carousel(5,1)
    1
    2
    3
    4
    5
    """
    # Your Code Here
