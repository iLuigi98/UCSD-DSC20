# Part 2. Back to basics.


import numpy as np
import pandas as pd
from datetime import *


table1 = pd.read_csv('data1.csv')
table2 = pd.read_csv('data2.csv')

#Your Code Here
